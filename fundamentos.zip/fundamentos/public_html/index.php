<?php
// public_html/index.php
require_once __DIR__.'/../includes/auth.php';   // arranca la sesión
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>IA-Lovers</title>
  <link rel="stylesheet" href="css/style.css">
</head>
<body>
 <?php require __DIR__.'/../includes/cabecera.php'; ?>
  <section class="hero">
    <div class="container">
      <h1>Bienvenido a IA-Lovers</h1>
      <p>Descubre, comparte y descarga memes, arte y literatura creada con IA.</p>
    </div>
  </section>

  <main class="container">
    <!-- Pestañas de categorías -->
    <div class="section-tabs">
      <button class="tab-btn active" data-cat="memes">Memes</button>
      <button class="tab-btn" data-cat="arte">Arte</button>
      <button class="tab-btn" data-cat="literatura">Literatura</button>
    </div>

    <!-- Secciones de catálogo -->
    <section id="memes" class="catalog active">
      <h2>Memes</h2>
      <div class="grid" id="memesGrid"></div>
    </section>
    <section id="arte" class="catalog">
      <h2>Arte</h2>
      <div class="grid" id="arteGrid"></div>
    </section>
    <section id="literatura" class="catalog">
      <h2>Literatura</h2>
      <div class="grid" id="literaturaGrid"></div>
    </section>
  </main>

  <!-- usa ruta absoluta, defer y versionado para evitar caché -->
<script src="/js/script.js" defer></script>


</body>
</html>
