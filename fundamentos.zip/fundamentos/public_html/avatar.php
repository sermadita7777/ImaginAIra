<?php
// public_html/avatar.php
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/bd.php';

// Solo usuarios logueados
if (!estaLogueado()) {
    header('HTTP/1.1 403 Forbidden');
    exit;
}

// Obtenemos usuario y ruta de avatar de la BD
$u = obtenerUsuarioPorId($_SESSION['usuario_id']);
$avatarPath = $u['avatar'] ?? null;  // puede ser null o 'avatars/archivo.ext'

// Construimos la ruta física correcta en storage
if ($avatarPath) {
    // Aseguramos no repetir carpeta 'avatars/'
    $relPath = ltrim($avatarPath, '/');
    // storage está en un nivel arriba de public_html
    $filePath = dirname(__DIR__) . "/storage/{$relPath}";
    if (file_exists($filePath)) {
        $file = $filePath;
    } else {
        $file = __DIR__ . '/imagenes/default-avatar.png';
    }
} else {
    $file = __DIR__ . '/imagenes/default-avatar.png';
}

// Servimos el fichero
$info = getimagesize($file);
header('Content-Type: ' . ($info['mime'] ?? 'application/octet-stream'));
readfile($file);
exit;
