<?php
// public_html/login/register.php

require_once __DIR__ . '/../../includes/auth.php';

// 1) Capturar y limpiar mensaje de error de sesión
$error = $_SESSION['error_register'] ?? '';
unset($_SESSION['error_register']);
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <title>Registrarse - IA-Lovers</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="/css/style.css">

  <?php if ($error): ?>
  <script>
    document.addEventListener('DOMContentLoaded', () => {
      alert(<?= json_encode($error) ?>);
    });
  </script>
  <?php endif; ?>
</head>
<body>

  <!-- Cabecera común -->
  <?php require_once __DIR__ . '/../../includes/cabecera.php'; ?>

  <!-- Formulario de registro -->
  <main class="auth-container">
    <div class="auth-card">
      <h2>Crear Cuenta</h2>
      <form
        id="registerForm"
        class="auth-form"
        action="/login/procesar_registro.php"
        method="post"
        enctype="multipart/form-data"
      >
        <div class="form-group">
          <label for="regName">Nombre real</label>
          <input type="text" id="regName" name="nombre" required>
        </div>
        <div class="form-group">
          <label for="regUser">Nombre de usuario</label>
          <input type="text" id="regUser" name="usuario" required>
        </div>
        <div class="form-group">
          <label for="regEmail">Email</label>
          <input type="email" id="regEmail" name="email" required>
        </div>
        <div class="form-group">
          <label for="regPass">Contraseña</label>
          <input type="password" id="regPass" name="contrasena" required>
        </div>
        <div class="form-group">
          <label for="regAvatar">Avatar (opcional)</label>
          <input type="file" id="regAvatar" name="avatar" accept="image/*">
        </div>
        <button type="submit" class="btn-solid btn-full">Registrarse</button>
      </form>
      <p class="auth-footer">
        ¿Tienes ya una cuenta?
        <a href="/login/ingreso.php">Inicia Sesión</a>
      </p>
    </div>
  </main>

  <!-- Scripts comunes -->
  <script src="/js/script.js" defer></script>
</body>
</html>
