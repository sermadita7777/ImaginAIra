<?php
require_once __DIR__ . '/../../includes/bd.php';
require_once __DIR__ . '/../../includes/auth.php';

$login     = trim($_POST['login'] ?? '');
$contrasena= $_POST['password'] ?? '';

if (!$login || !$contrasena) {
    die('Rellena todos los campos.');
}

// Decidir si es email o usuario
if (filter_var($login, FILTER_VALIDATE_EMAIL)) {
    $u = obtenerUsuarioPorEmail($login);
} else {
    $u = obtenerUsuarioPorUsuario($login);
}

if (!$u || !password_verify($contrasena, $u['password'])) {
    die('Usuario/email o contraseña incorrectos.');
}

// Iniciar sesión y redirigir
iniciarSesion($u['id'], $u['name'], $u['username']);
header('Location: /');
exit;
