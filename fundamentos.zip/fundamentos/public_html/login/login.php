<?php
// public_html/ingreso.php

// Arranca la sesión y las funciones de usuario
require_once __DIR__ . '/../../includes/auth.php';
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Iniciar Sesión - IA-Lovers</title>
  <link rel="stylesheet" href="../css/style.css">
</head>
<body>

  <!-- Cabecera común -->
  <?php require_once __DIR__ . '/../../includes/cabecera.php'; ?>

  <!-- Contenedor de autenticación -->
  <main class="auth-container">
    <div class="auth-card">
      <h2>Iniciar Sesión</h2>
      <!-- Formulario que envía al procesador PHP -->
      <form id="loginForm" class="auth-form" action="/login/procesar_ingreso.php" method="post">
        <div class="form-group">
          <label for="loginUser">Usuario o Email</label>
          <input
            type="text"
            id="loginUser"
            name="login"
            required
          >
        </div>
        <div class="form-group">
          <label for="loginPass">Contraseña</label>
          <input
            type="password"
            id="loginPass"
            name="password"
            required
          >
        </div>
        <button type="submit" class="btn-solid btn-full">Entrar</button>
      </form>
      <p class="auth-footer">
        ¿No tienes cuenta?
        <a href="/login/registro.php">Regístrate</a>
      </p>
    </div>
  </main>

  <!-- Scripts: tu lógica global y el manejador de login JS -->
  <script src="../js/script.js" defer></script>

</body>
</html>
