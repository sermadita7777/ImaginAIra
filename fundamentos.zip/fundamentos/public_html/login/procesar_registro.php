<?php
// public_html/login/procesar_registro.php

// Mostrar errores en desarrollo
ini_set('display_errors', 1);
error_reporting(E_ALL);

require_once __DIR__ . '/../../includes/auth.php';
require_once __DIR__ . '/../../includes/bd.php';

// 1) Recoge y sanitiza tus campos
$nombre     = trim($_POST['nombre']      ?? '');
$usuario    = trim($_POST['usuario']     ?? '');
$email      = trim($_POST['email']       ?? '');
$contrasena =         $_POST['contrasena'] ?? '';

// 2) Comprueba que el username no existe
if (obtenerUsuarioPorUsuario($usuario)) {
    $_SESSION['error_register'] = 'Ese nombre de usuario ya existe.';
    header("Location: /login/register.php");
    exit;
}

// 3) Comprueba que el email no existe
if (obtenerUsuarioPorEmail($email)) {
    $_SESSION['error_register'] = 'Ese correo electrónico ya está en uso.';
    header("Location: /login/register.php");
    exit;
}

// 4) Validación simple de formato de email
if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    $_SESSION['error_register'] = 'Por favor ingresa un email válido.';
    header("Location: /login/register.php");
    exit;
}

// 5) Guarda avatar si se subió uno
$avatarFile = null;
if (!empty($_FILES['avatar']['tmp_name']) && $_FILES['avatar']['error'] === UPLOAD_ERR_OK) {
    $ext = pathinfo($_FILES['avatar']['name'], PATHINFO_EXTENSION);
    $nuevoNombre = uniqid('avatar_') . '.' . $ext;
    $destino = RUTA_ALMACENAMIENTO . 'avatars/' . $nuevoNombre;
    if (move_uploaded_file($_FILES['avatar']['tmp_name'], $destino)) {
        $avatarFile = 'avatars/' . $nuevoNombre;
    }
}

// 6) Registra el usuario
if (!registrarUsuario($nombre, $usuario, $email, $contrasena, $avatarFile)) {
    $_SESSION['error_register'] = 'Error al crear el usuario. Intenta de nuevo.';
    header("Location: /login/register.php");
    exit;
}

// 7) Recupera el usuario recién creado
$u = obtenerUsuarioPorUsuario($usuario);
if (!$u) {
    $_SESSION['error_register'] = 'Error interno. Vuelve a intentarlo.';
    header("Location: /login/register.php");
    exit;
}

// 8) Inicia sesión y redirige al inicio
iniciarSesion($u['id'], $u['name'], $u['username']);
header('Location: /');
exit;
