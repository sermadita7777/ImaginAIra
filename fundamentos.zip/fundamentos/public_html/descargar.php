<?php
// public_html/descargar.php
require_once __DIR__ . '/../includes/auth.php';
requiereLogin();
require_once __DIR__ . '/../includes/bd.php';

// Recoger ID y buscar contenido IA
$id      = intval($_GET['id'] ?? 0);
$filas   = ejecutarConsulta('SELECT * FROM ai_contents WHERE id = ?', ['i', $id]);
$c       = $filas[0] ?? null;

if (!$c) {
    header('HTTP/1.1 404 Not Found');
    exit('Contenido no encontrado.');
}

// Solo dueño o admin
if ($c['user_id'] != $_SESSION['usuario_id'] && !esAdmin()) {
    header('HTTP/1.1 403 Forbidden');
    exit('Sin permiso.');
}

$ruta = __DIR__ . '/../storage/ai_contents/' . $c['file_path'];
if (!file_exists($ruta)) {
    header('HTTP/1.1 404 Not Found');
    exit('Archivo perdido.');
}

// Enviar fichero
header('Content-Type: ' . mime_content_type($ruta));
header('Content-Disposition: attachment; filename="' . basename($ruta) . '"');
readfile($ruta);
exit;
