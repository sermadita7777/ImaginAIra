<?php
// public_html/cerrar_sesion.php
require_once __DIR__ . '/../includes/auth.php';
cerrarSesion();
header('Location: /');
exit;
