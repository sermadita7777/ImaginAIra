<?php
// public_html/inicio.php
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <title>Inicio</title>
  <link rel="stylesheet" href="styles.css">
</head>
<body>
  <?php require_once __DIR__ . '/../includes/cabecera.php'; ?>
  <h1>Bienvenido al Catálogo IA</h1>
  <!-- Aquí iría tu galería, por ejemplo con fetch() a un script fetch_contenidos.php -->
</body>
</html>
