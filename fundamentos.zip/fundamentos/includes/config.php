<?php
define('BD_SERVIDOR',    'localhost');
define('BD_USUARIO',     '');
define('BD_CONTRASENA',  '');
define('BD_NOMBRE',      '');
define('RUTA_BASE',           '/'); 
define('RUTA_ALMACENAMIENTO', __DIR__ . '/../storage/');
