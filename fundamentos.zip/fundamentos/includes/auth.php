<?php
require_once 'config.php';
session_start();


function iniciarSesion(int $id, string $nombre, string $usuario): void {
    $_SESSION['usuario_id']      = $id;
    $_SESSION['usuario_nombre']  = $nombre;
    $_SESSION['usuario_usuario'] = $usuario;
}


function cerrarSesion(): void {
    session_unset();
    session_destroy();
}

function estaLogueado(): bool {
    return !empty($_SESSION['usuario_id']);
}

function requiereLogin(): void {
    if (!estaLogueado()) {
        header('Location: ingreso.php');
        exit;
    }
}


function esAdmin(): bool {
    return !empty($_SESSION['usuario_admin']) && $_SESSION['usuario_admin'] === true;
}
