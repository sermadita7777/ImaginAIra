<?php
// includes/bd.php
require_once 'config.php';

/**
 * Crea y devuelve la conexión a la base de datos.
 */
function conexionBD(): mysqli {
    $bd = new mysqli(BD_SERVIDOR, BD_USUARIO, BD_CONTRASENA, BD_NOMBRE);
    if ($bd->connect_error) {
        die('Error de conexión (' . $bd->connect_errno . '): ' . $bd->connect_error);
    }
    $bd->set_charset('utf8mb4');
    return $bd;
}

/**
 * Ejecuta una consulta SELECT y devuelve todas las filas.
 * @param string $sql       Consulta con placeholder '?'
 * @param array  $param     ['tipo…', valor1, valor2…]
 */
function ejecutarConsulta(string $sql, array $param = []): array {
    $bd   = conexionBD();
    $stmt = $bd->prepare($sql);
    if ($param) {
        $stmt->bind_param($param[0], ...array_slice($param, 1));
    }
    $stmt->execute();
    $result = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
    $stmt->close();
    $bd->close();
    return $result;
}

/**
 * Ejecuta INSERT/UPDATE/DELETE. Devuelve true si tuvo éxito.
 */
function ejecutarTransaccion(string $sql, array $param = []): bool {
    $bd   = conexionBD();
    $stmt = $bd->prepare($sql);
    if ($param) {
        $stmt->bind_param($param[0], ...array_slice($param, 1));
    }
    $ok = $stmt->execute();
    $stmt->close();
    $bd->close();
    return $ok;
}

/**
 * Registra un nuevo usuario. $avatar puede ser null o el nombre de archivo.
 */
function registrarUsuario(string $nombre, string $usuario, string $email, string $clave, ?string $avatar = null): bool {
    $hash = password_hash($clave, PASSWORD_DEFAULT);
    $sql  = 'INSERT INTO users (name, username, email, password, avatar) VALUES (?,?,?,?,?)';
    return ejecutarTransaccion($sql, ['sssss', $nombre, $usuario, $email, $hash, $avatar]);
}

/**
 * Obtiene un usuario por email, o null.
 */
function obtenerUsuarioPorEmail(string $email): ?array {
    $filas = ejecutarConsulta('SELECT * FROM users WHERE email = ?', ['s', $email]);
    return $filas[0] ?? null;
}

/**
 * Obtiene un usuario por username, o null.
 */
function obtenerUsuarioPorUsuario(string $usuario): ?array {
    $filas = ejecutarConsulta('SELECT * FROM users WHERE username = ?', ['s', $usuario]);
    return $filas[0] ?? null;
}

/**
 * Obtiene un usuario por su ID, o null.
 */
function obtenerUsuarioPorId(int $id): ?array {
    $filas = ejecutarConsulta('SELECT * FROM users WHERE id = ?', ['i', $id]);
    return $filas[0] ?? null;
}
